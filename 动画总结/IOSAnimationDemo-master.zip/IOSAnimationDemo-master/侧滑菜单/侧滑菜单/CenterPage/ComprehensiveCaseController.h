//
//  CenterView5Controller.h
//  侧滑菜单
//
//  Created by yixiang on 15/7/19.
//  Copyright (c) 2015年 yixiang. All rights reserved.
//

#import "BaseViewController.h"

@interface ComprehensiveCaseController : BaseViewController

@end
