# IOSAnimationDemo
IOS动画总结
<br/>
本案例主要实现的IOS侧滑菜单、IOS基础动画、关键帧动画、组动画、过渡动画和三个综合案例（仿造Path菜单，仿造dingding菜单，和烟花点赞效果等功能）。<br/>