//
//  main.m
//  Wheel
//
//  Created by huangyipeng on 14-9-3.
//  Copyright (c) 2014年 hyp. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "HYPAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([HYPAppDelegate class]));
    }
}
