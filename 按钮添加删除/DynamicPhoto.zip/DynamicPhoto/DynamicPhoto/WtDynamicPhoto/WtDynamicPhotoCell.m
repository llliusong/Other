//
//  WtDynamicPhotoCell.m
//  DynamicPhoto
//
//  Created by imac on 14-7-27.
//  Copyright (c) 2014年 imac. All rights reserved.
//

#import "WtDynamicPhotoCell.h"

@implementation WtDynamicPhotoCell

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
      
    }
    return self;
}



- (IBAction)addBtnAction:(UIButton *)sender {
}
@end
