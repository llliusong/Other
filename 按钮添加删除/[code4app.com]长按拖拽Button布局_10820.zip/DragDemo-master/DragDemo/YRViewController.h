//
//  YRViewController.h
//  DragDemo
//
//  Created by YANGRui on 14-5-27.
//  Copyright (c) 2014年 YANGReal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YRViewController : UIViewController

@end
