/**
 * BanBuAppDelegate
 * @description 本文件提供程序App代理功能
 * @package
 * @author 		linlinyin
 * @copyright 	Copyright (c) 2012-2020 
 * @version 		1.0
 */

#import <UIKit/UIKit.h>

@interface BanBuAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
