/**
 *
 * DragSortTest
 *
 * 本文件提供拖动排序 删除 程序的入口
 *
 * @author 		linlinyin
 * @copyright 	Copyright (c) 2012-2020
 * @version 	1.0
 * @package
 * @date        2014/04/04
 *
 */


#import <UIKit/UIKit.h>

#import "BanBuAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([BanBuAppDelegate class]));
    }
}
