//
//  DemoVC7Model.h
//  SDAutoLayout 测试 Demo
//
//  Created by gsd on 15/12/17.
//  Copyright © 2015年 gsd. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DemoVC7Model : NSObject

@property (nonatomic, copy) NSString *title;

@property (nonatomic, strong) NSArray *imagePathsArray;

@end
