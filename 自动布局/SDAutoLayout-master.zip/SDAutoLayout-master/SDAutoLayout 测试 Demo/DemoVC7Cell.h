//
//  DemoVC7Cell.h
//  SDAutoLayout 测试 Demo
//
//  Created by gsd on 15/12/17.
//  Copyright © 2015年 gsd. All rights reserved.
//

#import <UIKit/UIKit.h>

@class DemoVC7Model;

@interface DemoVC7Cell : UITableViewCell

@property (nonatomic, strong) DemoVC7Model *model;

@end